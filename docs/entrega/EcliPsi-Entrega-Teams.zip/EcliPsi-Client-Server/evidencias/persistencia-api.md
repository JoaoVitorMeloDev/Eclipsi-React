# Persistência da disponibilidade pela API em produção

Data do teste: 26/11/2026 (horário de Brasília, UTC-3). Serviço: https://eclipsi-pi-backend-ptcv.onrender.com/api/v1.
Perfil profissional fictício: 102. Horário futuro cadastrado (Brasília): 25/01/2027 às 11:19:24. UUID: ee751e6d-2c2c-4a0c-b53d-bed14abbed07.

A primeira leitura retornou uma grade vazia. Após o cadastro do horário, um novo login em conexão independente recebeu outro JWT. A agenda retornou o mesmo UUID e instante. Após a remoção do horário, a segunda sessão voltou a consultar a grade e confirmou a ausência do UUID. O cadastro do perfil de teste permanece no sistema.

| Hora de Brasília (UTC-3) | Requisição | HTTP |
| --- | --- | --- |
| 11:19:24 | POST /auth/register/doctor | 201 |
| 11:19:25 | GET /professionals/102/availability | 200 |
| 11:19:27 | POST /professional/availability | 201 |
| 11:19:31 | POST /auth/login | 200 |
| 11:19:32 | GET /professionals/102/availability | 200 |
| 11:19:34 | DELETE /professional/availability/ee751e6d-2c2c-4a0c-b53d-bed14abbed07 | 200 |
| 11:19:36 | GET /professionals/102/availability | 200 |

A evidência foi coletada pela API. O backend versionado implementa a remoção como exclusão lógica. Para conferir diretamente a linha no Supabase, execute:

```sql
SELECT id, professional_id, data_hora, ativo
FROM public.disponibilidades
WHERE id = 'ee751e6d-2c2c-4a0c-b53d-bed14abbed07'::uuid;
```
