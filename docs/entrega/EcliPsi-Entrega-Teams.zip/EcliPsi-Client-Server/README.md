# EcliPsi | Avaliação final de Client-Server

Aplicação de saúde mental que permite selecionar profissionais, consultar disponibilidades e agendar atendimentos. A demonstração acompanha um horário desde o cadastro pelo profissional até sua retirada da agenda do paciente.

## Equipe

- Erik Melado Carvalho
- Gabriel Felipe Belo de Moura
- João Vitor Lima Braga Graciliano de Melo
- Júlia Maria Silva Parra Torres
- Luís Filipe Harten Nogueira
- Maria Sophia Lima dos Santos
- Valentina Matias

## Como avaliar

1. Abra `01-Apresentacao-Banco.pdf` em tela cheia. A apresentação parte do modelo relacional e acompanha o horário de teste entre duas sessões. Em `evidencias/persistencia-api.md` estão os horários, os códigos HTTP e a consulta SQL para a conferência. O vídeo e as capturas ilustram o uso do aplicativo.
2. Siga o roteiro em `demonstracao.md` para acompanhar o CRUD e conferir a persistência usando contas fictícias.
3. Leia banco/schema-contexto.sql para consultar as seis tabelas documentadas pelo Supabase. O arquivo é uma referência de estrutura. banco/inventario-rls.csv registra o resultado da consulta ao catálogo fornecido pela equipe. Os nomes e as condições das políticas podem ser consultados com banco/conferencia.sql.

## Como a informação percorre a aplicação

O cliente Expo envia requisições HTTPS à API Flask hospedada no Render. No login, a API busca o usuário em public.users, verifica o hash da senha e emite um JWT. Nas chamadas protegidas, o cliente envia esse token no cabeçalho Authorization. O backend valida a sessão, verifica as permissões da operação e executa SQL parametrizado usando psycopg2. A conexão ao PostgreSQL do Supabase exige SSL e usa DATABASE_URL ou as variáveis DB_* do servidor. A API devolve JSON ao aplicativo.

## Organização dos dados

| Entidade | Relação e uso |
| --- | --- |
| users | Reúne perfis. O papel distingue pacientes, profissionais e administradores. |
| disponibilidades | Cada horário pertence a um profissional por professional_id. O campo ativo indica se o horário continua na grade. |
| consultas | Liga paciente e profissional a um horário. Os estados previstos são agendada, realizada e cancelada. |
| triagens | A chave patient_id vincula uma triagem ao paciente. Um novo envio atualiza suas preferências. |
| pagamentos | A cobrança pode referenciar uma consulta por consulta_id. |
| avaliacoes | Vincula paciente, profissional e consulta. A nota vai de 1 a 5 e consulta_id é único. |

## Fontes

- Aplicação publicada — https://eclipsi.dev
- Frontend e evidências — https://github.com/JoaoVitorMeloDev/Eclipsi-React/tree/2a32ddd
- Backend e migrations — https://github.com/JoaoVitorMeloDev/eclipsi-pi-BackEnd/tree/6d18d86
- Conexão — api/core/config.py e api/core/database.py no backend.
- CRUD — api/v1/endpoints/scheduling.py e api/v1/endpoints/patient.py no backend.

## Políticas em produção

banco/politicas-producao.csv transcreve as nove políticas exibidas em Database → Policies no painel de produção fornecido pela equipe. PUBLIC indica todos os papéis do banco. O acesso efetivo depende também dos privilégios e das condições de cada política.
