# Demonstração do CRUD

Use uma conta profissional e uma conta paciente destinadas à demonstração. Abra duas sessões do aplicativo e o Table Editor do Supabase. Filtre as tabelas pelos identificadores de teste e mostre apenas as colunas indicadas.

| Operação | Ação no aplicativo | Evidência no PostgreSQL |
| --- | --- | --- |
| Criar | Em Minha Disponibilidade, cadastre um horário futuro novo. A API recebe POST /api/v1/professional/availability. | Em disponibilidades, mostre id, professional_id, data_hora e ativo. Anote o UUID do horário ativo. |
| Consultar | Com a conta paciente, abra a agenda do mesmo profissional. Recarregue. O cliente chama GET /api/v1/professionals/{id}/availability. | Compare o horário exibido com a linha já identificada. O banco guarda o instante com fuso. A interface pode apresentá-lo no horário local. |
| Atualizar | No perfil profissional de teste, altere o nome e salve. O cliente envia PATCH /api/v1/profile/me. Reabra o perfil. | Em users, filtre pelo id do perfil. Mostre apenas id e nome antes e depois. O id permanece igual. Ao terminar, restaure o nome inicial. |
| Excluir | Remova o horário no painel profissional. O cliente envia DELETE /api/v1/professional/availability/{slot_id}. Reabra a agenda como paciente. | No mesmo UUID, ativo passa a false. A consulta de horários livres considera apenas registros ativos, futuros e desocupados. O histórico fica preservado por exclusão lógica. |

Para registrar a prova, capture o mesmo UUID após a criação e após a remoção e coloque a agenda ao lado do resultado. Um dado criado ao vivo e relido por outra sessão demonstra a integração. O endpoint /health informa se o Flask respondeu.

## Exportação opcional da estrutura instalada

Quem administra o projeto pode exportar a estrutura com pg_dump em versão compatível com o servidor. Em um terminal autorizado, com a variável DATABASE_URL já configurada para uma conexão direta ou pooler em modo sessão, execute:

```sh
pg_dump --dbname="$DATABASE_URL" --schema=public --schema-only --no-owner --no-privileges --file=schema.sql
```

Revise o SQL antes de compartilhá-lo, inclusive as definições de funções. Para consultar colunas, vínculos e índices no SQL Editor sem gerar dump, use banco/conferencia.sql.
