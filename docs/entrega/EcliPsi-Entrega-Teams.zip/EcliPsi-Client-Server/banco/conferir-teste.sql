-- Evidência de cadastro: projete somente estas colunas da conta fictícia.
SELECT id, nome, role, created_at FROM public.users WHERE id = 102;

-- Evidência do horário retirado: verificar ao vivo o valor de ativo.
SELECT id, professional_id, data_hora, ativo
FROM public.disponibilidades
WHERE professional_id = 102 AND id = 'ee751e6d-2c2c-4a0c-b53d-bed14abbed07'::uuid;
