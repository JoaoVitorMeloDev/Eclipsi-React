-- WARNING: This schema is for context only and is not meant to be run.
-- Table order and constraints may not be valid for execution.

CREATE TABLE public.users (
 id integer NOT NULL DEFAULT nextval('users_id_seq'::regclass),
 nome character varying NOT NULL,
 email character varying NOT NULL UNIQUE CHECK (email::text ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'::text),
 senha text NOT NULL,
 telefone character varying CHECK (telefone IS NULL OR telefone::text ~ '^\d{10,11}$'::text),
 role character varying NOT NULL CHECK (lower(role::text) = ANY (ARRAY['paciente'::text, 'medico'::text, 'profissional'::text, 'admin'::text])),
 idade integer CHECK (idade IS NULL OR idade >= 0 AND idade <= 120),
 genero character varying,
 especialidade character varying CHECK (especialidade IS NULL OR (especialidade::text = ANY (ARRAY['Psicólogo(a)'::character varying, 'Psiquiatra'::character varying, 'Psicanalista'::character varying, 'Neuropsicólogo(a)'::character varying]::text[]))),
 registro character varying,
 uf character,
 descricao text,
 created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
 foto text,
 valor_hora numeric,
 abordagem text,
 modalidade text,
 CONSTRAINT users_pkey PRIMARY KEY (id)
);
CREATE TABLE public.pagamentos (
 id bigint NOT NULL DEFAULT nextval('pagamentos_id_seq'::regclass),
 paciente_id integer,
 medico_id integer,
 valor numeric NOT NULL CHECK (valor >= 0::numeric),
 taxa_plataforma numeric NOT NULL DEFAULT 0,
 repasse numeric NOT NULL DEFAULT 0,
 status text NOT NULL DEFAULT 'pendente'::text CHECK (status = ANY (ARRAY['pendente'::text, 'pago'::text, 'cancelado'::text, 'estornado'::text])),
 criado_em timestamp with time zone NOT NULL DEFAULT now(),
 consulta_id bigint,
 metodo text,
 codigo_pix text,
 pix_id uuid,
 pix_mode text,
 pix_qr_base64 text,
 pix_provider_id text,
 pix_pago_em timestamp with time zone,
 CONSTRAINT pagamentos_pkey PRIMARY KEY (id),
 CONSTRAINT pagamentos_paciente_id_fkey FOREIGN KEY (paciente_id) REFERENCES public.users(id),
 CONSTRAINT pagamentos_medico_id_fkey FOREIGN KEY (medico_id) REFERENCES public.users(id),
 CONSTRAINT pagamentos_consulta_id_fkey FOREIGN KEY (consulta_id) REFERENCES public.consultas(id)
);
CREATE TABLE public.consultas (
 id bigint NOT NULL DEFAULT nextval('consultas_id_seq'::regclass),
 paciente_id integer NOT NULL,
 medico_id integer NOT NULL,
 data_hora timestamp with time zone NOT NULL,
 valor numeric NOT NULL DEFAULT 0,
 status text NOT NULL DEFAULT 'agendada'::text CHECK (status = ANY (ARRAY['agendada'::text, 'realizada'::text, 'cancelada'::text])),
 anotacoes text,
 criado_em timestamp with time zone NOT NULL DEFAULT now(),
 CONSTRAINT consultas_pkey PRIMARY KEY (id),
 CONSTRAINT consultas_paciente_id_fkey FOREIGN KEY (paciente_id) REFERENCES public.users(id),
 CONSTRAINT consultas_medico_id_fkey FOREIGN KEY (medico_id) REFERENCES public.users(id)
);
CREATE TABLE public.avaliacoes (
 id bigint NOT NULL DEFAULT nextval('avaliacoes_id_seq'::regclass),
 consulta_id bigint NOT NULL UNIQUE,
 medico_id integer NOT NULL,
 paciente_id integer NOT NULL,
 nota integer NOT NULL CHECK (nota >= 1 AND nota <= 5),
 comentario text,
 criado_em timestamp with time zone NOT NULL DEFAULT now(),
 CONSTRAINT avaliacoes_pkey PRIMARY KEY (id),
 CONSTRAINT avaliacoes_consulta_id_fkey FOREIGN KEY (consulta_id) REFERENCES public.consultas(id),
 CONSTRAINT avaliacoes_medico_id_fkey FOREIGN KEY (medico_id) REFERENCES public.users(id),
 CONSTRAINT avaliacoes_paciente_id_fkey FOREIGN KEY (paciente_id) REFERENCES public.users(id)
);
CREATE TABLE public.disponibilidades (
 id uuid NOT NULL DEFAULT gen_random_uuid(),
 professional_id bigint NOT NULL,
 data_hora timestamp with time zone NOT NULL,
 ativo boolean NOT NULL DEFAULT true,
 CONSTRAINT disponibilidades_pkey PRIMARY KEY (id),
 CONSTRAINT disponibilidades_professional_id_fkey FOREIGN KEY (professional_id) REFERENCES public.users(id)
);
CREATE TABLE public.triagens (
 patient_id bigint NOT NULL,
 motivo_principal text NOT NULL,
 abordagem_preferida text NOT NULL,
 modalidade text NOT NULL,
 faixa_valor_max numeric NOT NULL CHECK (faixa_valor_max > 0::numeric),
 urgencia text NOT NULL,
 atualizado_em timestamp with time zone NOT NULL DEFAULT now(),
 CONSTRAINT triagens_pkey PRIMARY KEY (patient_id),
 CONSTRAINT triagens_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.users(id)
);
