-- Execute cada SELECT separadamente no SQL Editor do Supabase.
-- As consultas leem metadados e preservam os dados das contas.
SELECT table_name, column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_schema = 'public'
  AND table_name IN ('avaliacoes','users','consultas','disponibilidades','triagens','pagamentos')
ORDER BY table_name, ordinal_position;

SELECT c.relname AS tabela, k.conname AS restricao, pg_get_constraintdef(k.oid) AS definicao
FROM pg_constraint k
JOIN pg_class c ON c.oid = k.conrelid
JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname = 'public'
  AND c.relname IN ('avaliacoes','users','consultas','disponibilidades','triagens','pagamentos')
ORDER BY tabela, restricao;

SELECT tablename, indexname, indexdef FROM pg_indexes
WHERE schemaname = 'public' AND tablename IN ('consultas','disponibilidades')
ORDER BY tablename, indexname;

-- Para comparar antes e depois, substitua o marcador pelo UUID do horário de teste.
-- SELECT id, professional_id, data_hora, ativo FROM public.disponibilidades
-- WHERE id = '<UUID do horário de teste>'::uuid;

SELECT tablename, policyname, roles, cmd, qual, with_check
FROM pg_policies WHERE schemaname = 'public' ORDER BY tablename, policyname;
